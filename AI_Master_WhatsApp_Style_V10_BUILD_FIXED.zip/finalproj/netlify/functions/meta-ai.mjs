const DEFAULT_URL = "https://api.llama.com/v1/chat/completions";
const DEFAULT_MODEL = "Llama-4-Maverick-17B-128E-Instruct-FP8";

function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" },
  });
}

export default async (request) => {
  if (request.method === "OPTIONS") return new Response(null, { status: 204 });
  if (request.method !== "POST") return json({ error: "Method not allowed" }, 405);

  const key = process.env.META_MODEL_API_KEY || process.env.META_AI_API_KEY || process.env.META_API_KEY || process.env.LLAMA_API_KEY;
  if (!key) return json({ error: "AI API key is missing. Add META_MODEL_API_KEY in Netlify Environment variables, then redeploy." }, 503);

  try {
    const input = await request.json();
    const messages = Array.isArray(input?.messages)
      ? input.messages
          .filter(m => ["user", "assistant", "developer", "system"].includes(m?.role) && typeof m?.content === "string")
          .slice(-20)
      : [];
    if (!messages.length) return json({ error: "No chat messages supplied." }, 400);

    const url = process.env.META_MODEL_API_URL || DEFAULT_URL;
    const model = process.env.META_MODEL_NAME || DEFAULT_MODEL;
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 45000);
    let upstream;
    try {
      upstream = await fetch(url, {
        method: "POST",
        headers: { "content-type": "application/json", authorization: `Bearer ${key}` },
        body: JSON.stringify({ model, messages, max_completion_tokens: 1024, temperature: 0.7 }),
        signal: controller.signal,
      });
    } finally {
      clearTimeout(timeout);
    }

    const raw = await upstream.text();
    let body;
    try { body = JSON.parse(raw); } catch { body = { raw }; }
    if (!upstream.ok) {
      const detail = body?.error?.message || body?.message || body?.raw || `HTTP ${upstream.status}`;
      return json({ error: String(detail).slice(0, 700) }, upstream.status);
    }

    let content = body?.choices?.[0]?.message?.content
      ?? body?.completion_message?.content?.text
      ?? body?.completion_message?.content
      ?? body?.output?.text;
    if (Array.isArray(content)) content = content.map(p => typeof p === "string" ? p : p?.text || p?.content || "").join("\n").trim();
    if (typeof content !== "string" || !content.trim()) return json({ error: "AI API returned no assistant text." }, 502);

    return json({ content, model });
  } catch (error) {
    const message = error?.name === "AbortError" ? "AI request timed out. Check the API key/model and try again." : (error?.message || "AI request failed");
    return json({ error: message }, 500);
  }
};
