const DEFAULT_URL = "https://api.llama.com/v1/chat/completions";
const DEFAULT_MODEL = "Llama-4-Maverick-17B-128E-Instruct-FP8";

function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      "content-type": "application/json; charset=utf-8",
      "cache-control": "no-store",
    },
  });
}

export default async (request) => {
  if (request.method === "OPTIONS") return new Response(null, { status: 204 });
  if (request.method !== "POST") return json({ error: "Method not allowed" }, 405);

  const key = process.env.META_MODEL_API_KEY;
  if (!key) return json({ error: "META_MODEL_API_KEY is not configured in Netlify." }, 503);

  try {
    const input = await request.json();
    const messages = Array.isArray(input?.messages)
      ? input.messages
          .filter((m) => ["user", "assistant", "developer", "system"].includes(m?.role) && typeof m?.content === "string")
          .slice(-20)
      : [];

    if (!messages.length) return json({ error: "No chat messages supplied." }, 400);

    const url = process.env.META_MODEL_API_URL || DEFAULT_URL;
    const model = process.env.META_MODEL_NAME || DEFAULT_MODEL;
    const upstream = await fetch(url, {
      method: "POST",
      headers: {
        "content-type": "application/json",
        authorization: `Bearer ${key}`,
      },
      body: JSON.stringify({
        model,
        messages,
        max_completion_tokens: 1024,
        temperature: 0.7,
      }),
    });

    const raw = await upstream.text();
    let body;
    try { body = JSON.parse(raw); } catch { body = { raw }; }

    if (!upstream.ok) {
      const detail = body?.error?.message || body?.message || body?.raw || `HTTP ${upstream.status}`;
      return json({ error: String(detail).slice(0, 700) }, upstream.status);
    }

    const content = body?.choices?.[0]?.message?.content
      ?? body?.completion_message?.content?.text
      ?? body?.completion_message?.content
      ?? body?.output?.text;

    if (typeof content !== "string") {
      return json({ error: "Meta/Llama API returned no assistant text." }, 502);
    }

    return json({ content, model });
  } catch (error) {
    return json({ error: error?.message || "AI request failed" }, 500);
  }
};
